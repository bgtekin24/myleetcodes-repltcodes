import java.util.*;
class Main {
  public static void main(String[] args) {
     //DO NOT TOUCH THESE LINES. TEACHER NEEDS THEM TO TEST YOUR CODE:
    // Variables are already declared and given
    Scanner s = new Scanner(System.in);
    
    int house = s.nextInt();
    int player = s.nextInt();
    
  if (player>21) {
    System.out.println("player bust");
      }
  else if (house>player) {
    System.out.println("player loss ");
      }  //Write your code here:
  else if (house==player) {
    System.out.println("its a tie");
      }  //Write your code here:
  else if (house<player) {
    System.out.println("player win");
      }  //Write your code here:
    //Write your code here:
    
    

  


  

    
  }
}