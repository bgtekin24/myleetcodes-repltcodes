import java.util.*;
class Main {
  static double price;
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    String in = s.next();
    

    switch(in)  {
      case "burger":
      price=10.0;
      System.out.println(price);
      break;
      case "chicken": 
      price=10.0;
      System.out.println(price);
      break;
      case "soda": 
      price=2.0;
      System.out.println(price);
      break;
      case "fries":
      price=3.5;
      System.out.println(price);
      break;
    }
    //your code here



  

    
  }
}