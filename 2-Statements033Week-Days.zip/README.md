Write a program that will print a week days according to the day number. Use  Switch statement. If an invalid day is entered print: "Not a valid day"

 

Example

```
Enter number:
1

Output: Monday
```
```
Enter number:
7

Output: Sunday
```