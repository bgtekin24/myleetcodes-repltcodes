import java.util.*;

public class Main {
  public static void main(String[] args) {
  Scanner sc=new Scanner (System.in);
  

System.out.println("Select screen size:");
double inputs=sc.nextDouble();
double lprice=0.0;
if (inputs==13.3) {
  lprice+=200;
} else if (inputs==15.0) {
  lprice+=300;
} else if (inputs==17.3) {
  lprice+=400;
} else {

}
System.out.println("Select CPU type:");
String inputC=sc.next();
switch (inputC) {
  case "i3": 
  lprice+=150;
  break;
  case "i5":
  lprice+=250;
  break;
  case "i7":
  lprice+=350;
  break;
  default:
  break;
}
System.out.println("Select RAM size:");
int inputR=sc.nextInt();
if (inputR%4==0) {
  lprice+=50*(inputR/4);
}
System.out.println("Select storage type:");
System.out.println("Enter memory size:");
String inputS=sc.next();
int inputM=sc.nextInt();

switch(inputS) {
  case "HDD":
  lprice+=50*(inputM/500);
  break;
  case "SSD":
  lprice+=100*(inputM/500);
  break;
}
System.out.println("Enter screen resolution:");
String inputSR=sc.next();
switch(inputSR) {
case "FULLHD":
lprice+=100;
break;
case "4K":
lprice+=200;
break;
}
 System.out.println("Laptop price is: "+'$'+lprice);
}
}