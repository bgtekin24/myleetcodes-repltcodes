Write a program that will return mid number out of three numbers.  No need to do any calculations.


1. Create an object of Scanner class. 

2. Declare int 3 variables: num1, num2, num3.

Example:

```
Enter first number:
14
Enter second number:
52
Enter third number:
25

Medium value is: 25
```
```

Enter first number:
140
Enter second number:
34
Enter third number:
1

Medium value is: 34
```